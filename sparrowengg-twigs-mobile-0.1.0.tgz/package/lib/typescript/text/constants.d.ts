export declare const DEFAULT_FONT_SIZE = 14;
export declare const WEIGHT_TO_FONT_WEIGHT: Record<'regular' | 'medium' | 'bold', string>;
//# sourceMappingURL=constants.d.ts.map