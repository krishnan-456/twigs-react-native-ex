import type { TextStyle, ViewStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { DropdownMenuSize } from './types';
export declare function getItemSizeStyles(size: DropdownMenuSize): ViewStyle;
export declare function getItemTextStyles(theme: TwigsTheme, size: DropdownMenuSize): TextStyle;
export declare function getItemPressedStyles(theme: TwigsTheme): ViewStyle;
export declare function getItemDisabledStyles(): ViewStyle;
export declare function getContentStyles(theme: TwigsTheme): ViewStyle;
export declare function getLabelTextStyles(theme: TwigsTheme, size: DropdownMenuSize): TextStyle;
//# sourceMappingURL=helpers.d.ts.map