import type { DropdownMenuSize } from './types';
interface SizeConfig {
    itemHeight: number;
    paddingHorizontal: number;
    fontSize: number;
    lineHeight: number;
    labelFontSize: number;
    labelLineHeight: number;
}
export declare const SIZE_CONFIG: Record<DropdownMenuSize, SizeConfig>;
export declare const DEFAULT_SIZE: DropdownMenuSize;
export declare const CONTENT_BORDER_RADIUS = 12;
export declare const CONTENT_PADDING_VERTICAL = 8;
export declare const CONTENT_MIN_WIDTH = 180;
export declare const HIDDEN: {
    readonly opacity: 0;
};
export declare const VISIBLE: {
    readonly opacity: 1;
};
export {};
//# sourceMappingURL=constants.d.ts.map