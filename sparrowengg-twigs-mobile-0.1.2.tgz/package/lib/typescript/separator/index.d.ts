export { Separator } from './separator';
export type { SeparatorProps, SeparatorOrientation } from './types';
//# sourceMappingURL=index.d.ts.map