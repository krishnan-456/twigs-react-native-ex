import React from 'react';
import { View } from 'react-native';
import type { SeparatorProps } from './types';
/** Visual divider line, horizontal or vertical, with optional decorative mode. */
export declare const Separator: React.ForwardRefExoticComponent<SeparatorProps & React.RefAttributes<View>>;
//# sourceMappingURL=separator.d.ts.map