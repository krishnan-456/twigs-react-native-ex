import React from 'react';
import { View } from 'react-native';
import type { BoxProps } from './types';
/** Basic layout container with margin and padding shorthand props. */
export declare const Box: React.ForwardRefExoticComponent<BoxProps & React.RefAttributes<View>>;
//# sourceMappingURL=box.d.ts.map