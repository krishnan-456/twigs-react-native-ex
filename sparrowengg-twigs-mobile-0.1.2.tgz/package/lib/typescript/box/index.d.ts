export { Box } from './box';
export type { BoxProps } from './types';
//# sourceMappingURL=index.d.ts.map