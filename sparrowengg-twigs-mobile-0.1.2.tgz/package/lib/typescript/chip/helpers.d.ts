import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { ChipSize, ChipColor, ChipRounded } from './types';
export declare function getSizeStyles(size: ChipSize, rounded: ChipRounded): ViewStyle;
export declare function getRegularStyles(theme: TwigsTheme, color: ChipColor): ViewStyle;
export declare function getPressedStyles(theme: TwigsTheme, color: ChipColor): ViewStyle;
export declare function getActiveStyles(theme: TwigsTheme, color: ChipColor): ViewStyle;
export declare function getTextStyles(theme: TwigsTheme, color: ChipColor, size: ChipSize, active: boolean): TextStyle;
export declare function getIconSize(size: ChipSize): number;
export declare function getIconColor(theme: TwigsTheme, color: ChipColor, active: boolean): string;
//# sourceMappingURL=helpers.d.ts.map