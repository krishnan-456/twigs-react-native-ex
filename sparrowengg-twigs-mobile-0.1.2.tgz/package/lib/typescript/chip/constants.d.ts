import type { ThemeColors } from '../theme';
import type { ChipSize, ChipColor, ChipRounded } from './types';
interface SizeConfig {
    height: number;
    paddingHorizontal: number;
    fontSize: number;
    lineHeight: number;
    iconSize: number;
}
interface ChipColorTokens {
    regularBg: keyof ThemeColors;
    regularBorder: keyof ThemeColors;
    regularText: keyof ThemeColors;
    pressedBgBase: keyof ThemeColors;
    pressedBgOpacity: number;
    pressedBorder: keyof ThemeColors;
    pressedText: keyof ThemeColors;
    activeBg: keyof ThemeColors | null;
    activeBgBase: keyof ThemeColors | null;
    activeBgOpacity: number;
    activeBorder: keyof ThemeColors | null;
    activeText: keyof ThemeColors;
}
export declare const SIZE_CONFIG: Record<ChipSize, SizeConfig>;
export declare const ROUNDED_RADII: Record<ChipRounded, number>;
export declare const COLOR_TOKENS: Record<ChipColor, ChipColorTokens>;
export declare const DEFAULT_SIZE: ChipSize;
export declare const DEFAULT_COLOR: ChipColor;
export declare const DEFAULT_ROUNDED: ChipRounded;
export {};
//# sourceMappingURL=constants.d.ts.map