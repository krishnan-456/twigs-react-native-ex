import React from 'react';
import { View } from 'react-native';
import type { ChipProps } from './types';
/** Selectable pill for filters, tags, and selections with normal/pressed/active states. */
export declare const Chip: React.ForwardRefExoticComponent<ChipProps & React.RefAttributes<View>>;
//# sourceMappingURL=chip.d.ts.map