import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { AlertStatus } from './types';
export declare function getStatusContainerStyles(theme: TwigsTheme, status: AlertStatus): ViewStyle;
export declare function getIconColor(theme: TwigsTheme, status: AlertStatus): string;
export declare function getTextStyles(theme: TwigsTheme): TextStyle;
//# sourceMappingURL=helpers.d.ts.map