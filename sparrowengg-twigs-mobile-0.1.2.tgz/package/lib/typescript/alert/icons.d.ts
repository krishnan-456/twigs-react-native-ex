import React from 'react';
interface IconProps {
    size: number;
    color: string;
}
/** Default info icon */
export declare const InfoIcon: ({ size, color }: IconProps) => React.JSX.Element;
/** Default success icon */
export declare const SuccessIcon: ({ size, color }: IconProps) => React.JSX.Element;
/** Default warning icon */
export declare const WarningIcon: ({ size, color }: IconProps) => React.JSX.Element;
/** Default error icon */
export declare const ErrorIcon: ({ size, color }: IconProps) => React.JSX.Element;
/** Close icon */
export declare const CloseIcon: ({ size, color }: IconProps) => React.JSX.Element;
/** Map status to default icon component */
export declare const STATUS_ICONS: {
    default: ({ size, color }: IconProps) => React.JSX.Element;
    info: ({ size, color }: IconProps) => React.JSX.Element;
    success: ({ size, color }: IconProps) => React.JSX.Element;
    warning: ({ size, color }: IconProps) => React.JSX.Element;
    error: ({ size, color }: IconProps) => React.JSX.Element;
};
export {};
//# sourceMappingURL=icons.d.ts.map