import type { AlertStatus } from './types';
export declare const ALERT_BORDER_WIDTH = 1;
export declare const ALERT_PADDING_LEFT = 11;
export declare const ALERT_PADDING_RIGHT = 7;
export declare const ALERT_PADDING_VERTICAL = 7;
export declare const ALERT_GAP = 8;
export declare const ALERT_BORDER_RADIUS = 8;
export declare const ALERT_FONT_SIZE = 14;
export declare const ALERT_LINE_HEIGHT = 20;
export declare const ALERT_ICON_SIZE = 20;
export declare const ALERT_CLOSE_ICON_SIZE = 16;
export declare const ALERT_MIN_HEIGHT = 40;
export declare const ALERT_TEXT_COLOR = "neutral900";
export declare const DEFAULT_STATUS: AlertStatus;
export declare const STATUS_BG_COLORS: Record<AlertStatus, string>;
export declare const STATUS_BORDER_COLORS: Record<AlertStatus, string>;
export declare const STATUS_ICON_COLORS: Record<AlertStatus, string>;
//# sourceMappingURL=constants.d.ts.map