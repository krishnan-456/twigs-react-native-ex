export declare const styles: {
    container: {
        flexDirection: "row";
        alignItems: "center";
        paddingLeft: number;
        paddingRight: number;
        paddingVertical: number;
        gap: number;
        borderRadius: number;
        overflow: "hidden";
        minHeight: number;
    };
    iconContainer: {
        alignItems: "center";
        justifyContent: "center";
    };
    contentContainer: {
        flex: number;
    };
    closeButton: {
        alignItems: "center";
        justifyContent: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map