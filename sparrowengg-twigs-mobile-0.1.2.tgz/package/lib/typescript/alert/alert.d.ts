import React from 'react';
import { View } from 'react-native';
import type { AlertProps } from './types';
/** Contextual feedback banner with status icon, content, and optional close action. */
export declare const Alert: React.ForwardRefExoticComponent<AlertProps & React.RefAttributes<View>>;
//# sourceMappingURL=alert.d.ts.map