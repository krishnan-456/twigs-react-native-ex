import React from 'react';
import { TextInput as RNTextInput } from 'react-native';
import type { TextInputProps } from './types';
/** Themed text input with size/variant presets, icon slots, label, error state, and helper text. */
export declare const TextInput: React.ForwardRefExoticComponent<TextInputProps & React.RefAttributes<RNTextInput>>;
//# sourceMappingURL=text-input.d.ts.map