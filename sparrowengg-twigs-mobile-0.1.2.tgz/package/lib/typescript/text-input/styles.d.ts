/** Static layout styles — no theme colors here. Theme-dependent styles go in helpers or component. */
export declare const styles: {
    container: {
        position: "relative";
        width: "100%";
    };
    fullWidth: {
        width: "100%";
    };
    inputWrapper: {
        position: "relative";
        width: "100%";
        borderWidth: number;
        borderStyle: "solid";
        flexDirection: "row";
        alignItems: "center";
    };
    textInput: {
        outlineStyle?: string | undefined;
        outlineWidth?: number | undefined;
        outlineColor?: string | undefined;
        flex: number;
        margin: number;
        padding: number;
        borderWidth: number;
        backgroundColor: string;
        textAlignVertical: "center";
    };
    iconContainer: {
        justifyContent: "center";
        alignItems: "center";
    };
    labelRow: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    labelWithIndicator: {
        flexDirection: "row";
        alignItems: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map