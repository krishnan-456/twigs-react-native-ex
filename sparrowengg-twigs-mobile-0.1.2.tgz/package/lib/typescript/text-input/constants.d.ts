import type { TextInputSize } from './types';
export interface TextInputSizeConfig {
    /** Input field height in dp. */
    height: number;
    /** Border radius in dp. */
    borderRadius: number;
    /** Placeholder / input text font size in dp. */
    fontSize: number;
    /** Horizontal padding inside the input in dp. */
    paddingHorizontal: number;
    /** Font size for the label text above the input. */
    labelFontSize: number;
    /** Line height for label text. */
    labelLineHeight: number;
    /** Letter spacing for label text. */
    labelLetterSpacing: number;
    /** Line height for placeholder / input text. */
    inputLineHeight: number;
    /** Icon width & height in dp. */
    iconSize: number;
    /** Gap between icon and text inside the input. */
    iconTextGap: number;
}
/** Resolved size config for a given text-input size. */
export declare const getSizeConfig: (size: TextInputSize) => TextInputSizeConfig;
//# sourceMappingURL=constants.d.ts.map