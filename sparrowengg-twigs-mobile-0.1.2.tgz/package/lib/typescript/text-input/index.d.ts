export { TextInput } from './text-input';
export type { TextInputProps, TextInputSize, TextInputVariant } from './types';
//# sourceMappingURL=index.d.ts.map