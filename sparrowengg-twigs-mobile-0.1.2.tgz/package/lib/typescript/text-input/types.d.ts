import type { ReactElement, ReactNode } from 'react';
import type { TextInputProps as RNTextInputProps } from 'react-native';
import type { CommonStyleProps, BaseAccessibilityProps } from '../utils';
export type TextInputSize = 'lg' | 'xl';
export type TextInputVariant = 'default' | 'filled';
export interface TextInputProps extends Omit<RNTextInputProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Size preset controlling height, font size, and icon dimensions. @default 'lg' */
    size?: TextInputSize;
    /** Visual variant. @default 'default' */
    variant?: TextInputVariant;
    /** Icon rendered inside the input on the left. */
    leftIcon?: ReactElement;
    /** Icon rendered inside the input on the right. */
    rightIcon?: ReactElement;
    /** Arbitrary element rendered on the right (outside the icon slot). */
    rightElement?: ReactElement;
    /** Arbitrary element rendered on the left (outside the icon slot). */
    leftElement?: ReactElement;
    disabled?: boolean;
    /** Error message shown below the input. When present, error border styling is applied automatically. */
    errorMessage?: string;
    /** Label text rendered above the input. */
    label?: string;
    /** Helper text rendered below the input (hidden when errorMessage is present). */
    helperText?: string;
    /** Show character count next to the label. Requires `maxLength` to be set. @default false */
    showCount?: boolean;
    /** Show a required indicator next to the label. Pass `true` for default "*" or a custom ReactElement. @default false */
    requiredIndicator?: boolean | ReactElement;
    /** Custom renderer for the character counter. Overrides the default `{length}/{maxLength}` display. */
    renderCounter?: (info: {
        length: number;
        maxLength: number;
    }) => ReactNode;
}
//# sourceMappingURL=types.d.ts.map