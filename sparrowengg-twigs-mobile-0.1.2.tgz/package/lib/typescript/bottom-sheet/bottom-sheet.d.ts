import React from 'react';
import type { BottomSheetProps } from './types';
/** Themed wrapper around @gorhom/bottom-sheet with a built-in drag handle and optional title. */
export declare const BottomSheet: React.ForwardRefExoticComponent<BottomSheetProps & React.RefAttributes<import("@gorhom/bottom-sheet/lib/typescript/types").BottomSheetMethods>>;
//# sourceMappingURL=bottom-sheet.d.ts.map