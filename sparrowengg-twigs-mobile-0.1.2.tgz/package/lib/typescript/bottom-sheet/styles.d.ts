import { ViewStyle, StyleProp } from 'react-native';
import type { AnimateStyle } from 'react-native-reanimated';
import type { TwigsTheme } from '../theme';
/**
 * Gorhom BottomSheet expects an animated-compatible style type.
 * We narrow the allowed keys to avoid conflicts with internal layout props.
 */
export type AnimatedViewStyle = StyleProp<AnimateStyle<Omit<ViewStyle, 'left' | 'right' | 'top' | 'bottom' | 'position' | 'opacity' | 'flexDirection' | 'transform'>>>;
/** Default container style shared by BottomSheet and BottomSheetModal. */
export declare const getDefaultSheetStyle: (theme: TwigsTheme, safeAreaBottomInset: number, overrides?: ViewStyle) => AnimatedViewStyle;
//# sourceMappingURL=styles.d.ts.map