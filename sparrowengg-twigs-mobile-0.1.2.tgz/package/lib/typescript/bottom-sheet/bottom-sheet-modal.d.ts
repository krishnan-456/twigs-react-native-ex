import { BottomSheetModal as GorhomBottomSheetModal } from '@gorhom/bottom-sheet';
import React from 'react';
import type { BottomSheetModalProps } from './types';
/** Modal variant of BottomSheet that presents on top of a backdrop overlay. */
export declare const BottomSheetModal: React.ForwardRefExoticComponent<BottomSheetModalProps & React.RefAttributes<GorhomBottomSheetModal>>;
//# sourceMappingURL=bottom-sheet-modal.d.ts.map