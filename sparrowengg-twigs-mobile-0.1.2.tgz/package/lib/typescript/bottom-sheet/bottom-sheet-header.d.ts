import React from 'react';
import type { BottomSheetHeaderProps } from './types';
export declare const BottomSheetHeader: React.NamedExoticComponent<BottomSheetHeaderProps>;
//# sourceMappingURL=bottom-sheet-header.d.ts.map