import React from 'react';
import { View } from 'react-native';
import type { ModalBodyProps } from './types';
/**
 * ModalBody renders the main content area between header and footer.
 * Supports optional scrolling via the `scrollable` prop.
 */
export declare const ModalBody: React.ForwardRefExoticComponent<ModalBodyProps & React.RefAttributes<View>>;
//# sourceMappingURL=modal-body.d.ts.map