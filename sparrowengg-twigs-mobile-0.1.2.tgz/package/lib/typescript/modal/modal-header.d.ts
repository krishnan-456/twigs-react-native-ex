import React from 'react';
import { View } from 'react-native';
import type { ModalHeaderProps } from './types';
/**
 * ModalHeader renders a header section containing title and description.
 * Centered layout with gap between children.
 */
export declare const ModalHeader: React.ForwardRefExoticComponent<ModalHeaderProps & React.RefAttributes<View>>;
//# sourceMappingURL=modal-header.d.ts.map