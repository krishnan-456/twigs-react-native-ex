export declare const styles: {
    overlay: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
    };
    backdropPressable: {
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    content: {
        overflow: "hidden";
    };
    header: {
        paddingTop: number;
        paddingHorizontal: number;
        gap: number;
        alignItems: "center";
    };
    body: {
        paddingHorizontal: number;
        paddingVertical: number;
    };
    footer: {
        paddingHorizontal: number;
        paddingBottom: number;
        paddingTop: number;
        flexDirection: "row";
        gap: number;
    };
    footerChild: {
        flex: number;
    };
};
//# sourceMappingURL=styles.d.ts.map