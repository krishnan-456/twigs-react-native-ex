import React from 'react';
import { View } from 'react-native';
import type { ModalContentProps } from './types';
/**
 * ModalContent renders the white card container with rounded corners and shadow.
 * Place inside Modal as the direct child.
 */
export declare const ModalContent: React.ForwardRefExoticComponent<ModalContentProps & React.RefAttributes<View>>;
//# sourceMappingURL=modal-content.d.ts.map