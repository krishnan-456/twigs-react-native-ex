import React from 'react';
import type { ModalDescriptionProps } from './types';
/**
 * ModalDescription renders secondary descriptive text below the title.
 */
export declare const ModalDescription: React.FC<ModalDescriptionProps>;
//# sourceMappingURL=modal-description.d.ts.map