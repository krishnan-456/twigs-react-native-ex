import React from 'react';
import type { ModalTitleProps } from './types';
/**
 * ModalTitle renders the modal title text with bold typography.
 */
export declare const ModalTitle: React.FC<ModalTitleProps>;
//# sourceMappingURL=modal-title.d.ts.map