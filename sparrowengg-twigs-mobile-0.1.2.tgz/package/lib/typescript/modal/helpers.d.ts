import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { ModalSize } from './types';
export declare function getBackdropStyle(theme: TwigsTheme): ViewStyle;
export declare function getContentStyles(theme: TwigsTheme, size: ModalSize, screenWidth: number): ViewStyle;
export declare function getTitleStyles(theme: TwigsTheme): TextStyle;
export declare function getDescriptionStyles(theme: TwigsTheme): TextStyle;
//# sourceMappingURL=helpers.d.ts.map