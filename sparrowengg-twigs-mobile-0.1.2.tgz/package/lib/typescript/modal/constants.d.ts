import type { ModalSize, ModalAnimationType } from './types';
interface ContentSizeConfig {
    /** Horizontal margin from screen edge (applied to each side) */
    horizontalMargin: number;
}
export declare const CONTENT_SIZE_CONFIG: Record<ModalSize, ContentSizeConfig>;
export declare const DEFAULT_SIZE: ModalSize;
export declare const DEFAULT_ANIMATION_TYPE: ModalAnimationType;
export declare const CONTENT_BORDER_RADIUS = 16;
export declare const CONTENT_PADDING_HORIZONTAL = 16;
export declare const HEADER_PADDING_TOP = 32;
export declare const HEADER_PADDING_HORIZONTAL = 16;
export declare const HEADER_GAP = 4;
export declare const BODY_PADDING_HORIZONTAL = 16;
export declare const BODY_PADDING_VERTICAL = 16;
export declare const FOOTER_PADDING_HORIZONTAL = 16;
export declare const FOOTER_PADDING_BOTTOM = 16;
export declare const FOOTER_PADDING_TOP = 24;
export declare const FOOTER_GAP = 8;
export declare const TITLE_FONT_SIZE = 18;
export declare const TITLE_LINE_HEIGHT = 26;
export declare const DESCRIPTION_FONT_SIZE = 16;
export declare const DESCRIPTION_LINE_HEIGHT = 24;
export declare const BACKDROP_OPACITY = 0.5;
export {};
//# sourceMappingURL=constants.d.ts.map