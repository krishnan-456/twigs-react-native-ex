import React from 'react';
import { View } from 'react-native';
import type { ModalFooterProps } from './types';
/**
 * ModalFooter renders the action area at the bottom of the modal.
 * Children (typically Buttons) are laid out in a row with equal width.
 */
export declare const ModalFooter: React.ForwardRefExoticComponent<ModalFooterProps & React.RefAttributes<View>>;
//# sourceMappingURL=modal-footer.d.ts.map