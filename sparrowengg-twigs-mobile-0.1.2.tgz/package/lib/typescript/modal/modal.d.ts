import React from 'react';
import { View } from 'react-native';
import type { ModalProps } from './types';
/**
 * Modal root component wrapping React Native Modal.
 * Provides a backdrop overlay and centers children.
 *
 * Mobile deviation: Uses `visible` prop instead of Radix Trigger/Close pattern.
 * Android back button triggers `onClose` via `onRequestClose`.
 */
export declare const Modal: React.ForwardRefExoticComponent<ModalProps & React.RefAttributes<View>>;
//# sourceMappingURL=modal.d.ts.map