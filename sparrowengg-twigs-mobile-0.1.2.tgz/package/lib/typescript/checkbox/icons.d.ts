import React from 'react';
interface IconProps {
    size?: number;
    color?: string;
}
export declare const TickIcon: React.FC<IconProps>;
export declare const HorizontalLineIcon: React.FC<IconProps>;
export {};
//# sourceMappingURL=icons.d.ts.map