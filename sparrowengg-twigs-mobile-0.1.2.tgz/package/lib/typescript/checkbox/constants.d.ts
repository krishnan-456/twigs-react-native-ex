import type { CheckboxSize } from './types';
export interface CheckboxSizeConfig {
    width: number;
    height: number;
    iconSize: number;
}
export declare const CHECKBOX_SIZE_CONFIGS: Record<CheckboxSize, CheckboxSizeConfig>;
/** Returns resolved size config for the checkbox variant. */
export declare const getCheckboxSizeConfig: (size: CheckboxSize) => CheckboxSizeConfig;
//# sourceMappingURL=constants.d.ts.map