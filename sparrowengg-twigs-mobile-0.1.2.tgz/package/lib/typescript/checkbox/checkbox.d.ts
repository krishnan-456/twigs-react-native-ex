import React from 'react';
import { View } from 'react-native';
import type { CheckboxProps } from './types';
/** Checkbox with checked, unchecked, and indeterminate states, supporting an optional label. */
export declare const Checkbox: React.ForwardRefExoticComponent<CheckboxProps & React.RefAttributes<View>>;
//# sourceMappingURL=checkbox.d.ts.map