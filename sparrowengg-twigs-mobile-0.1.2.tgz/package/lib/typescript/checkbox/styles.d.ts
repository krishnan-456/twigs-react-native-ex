import type { TwigsTheme } from '../theme';
export declare const createCheckboxStyles: (theme: TwigsTheme) => {
    checkboxBase: {
        borderRadius: number;
        alignItems: "center";
        justifyContent: "center";
        borderWidth: number;
    };
    iconContainer: {
        alignItems: "center";
        justifyContent: "center";
    };
    labelContainer: {
        marginLeft: number;
    };
    container: {
        flexDirection: "row";
        alignItems: "center";
        alignSelf: "flex-start";
    };
    containerDisabled: {
        opacity: number;
    };
};
//# sourceMappingURL=styles.d.ts.map