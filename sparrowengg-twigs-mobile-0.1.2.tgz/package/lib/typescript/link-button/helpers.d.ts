import type { TextStyle, ViewStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { LinkButtonSize, LinkButtonColor, LinkButtonVariant } from './types';
export declare const getLinkButtonTextStyles: ({ size, color, variant, pressed, theme, }: {
    size: LinkButtonSize;
    color: LinkButtonColor;
    variant: LinkButtonVariant;
    pressed: boolean;
    theme: TwigsTheme;
}) => TextStyle;
export declare const getLinkButtonPressedStyle: (color: LinkButtonColor, theme: TwigsTheme) => ViewStyle;
//# sourceMappingURL=helpers.d.ts.map