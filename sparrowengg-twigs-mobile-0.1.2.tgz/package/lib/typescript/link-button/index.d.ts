export { LinkButton } from './link-button';
export type { LinkButtonProps, LinkButtonSize, LinkButtonColor, LinkButtonVariant } from './types';
//# sourceMappingURL=index.d.ts.map