import React from 'react';
import { View } from 'react-native';
import type { LinkButtonProps } from './types';
/**
 * A text-only pressable element styled as a hyperlink with underline decoration.
 * Supports size, color, and variant options with pressed/disabled states.
 */
export declare const LinkButton: React.ForwardRefExoticComponent<LinkButtonProps & React.RefAttributes<View>>;
//# sourceMappingURL=link-button.d.ts.map