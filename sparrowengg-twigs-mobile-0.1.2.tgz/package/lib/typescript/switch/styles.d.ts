import type { TwigsTheme } from '../theme';
export declare const createSwitchStyles: (theme: TwigsTheme) => {
    switchBase: {
        borderRadius: number;
        justifyContent: "center";
    };
    thumbBase: {
        borderRadius: number;
        backgroundColor: string;
    };
};
//# sourceMappingURL=styles.d.ts.map