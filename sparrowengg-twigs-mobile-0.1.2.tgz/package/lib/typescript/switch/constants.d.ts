import type { SwitchColor, SwitchSize } from './types';
export interface SwitchSizeConfig {
    track: {
        width: number;
        height: number;
    };
    thumb: {
        size: number;
        offPosition: number;
        onPosition: number;
    };
}
export declare const SWITCH_SIZE_CONFIGS: Record<SwitchSize, SwitchSizeConfig>;
export declare const DEFAULT_SWITCH_SIZE: SwitchSize;
export declare const CHECKED_COLOR_MAP: Record<SwitchColor, 'primary500' | 'secondary600'>;
export declare const getSwitchSizeConfig: (size: SwitchSize) => SwitchSizeConfig;
//# sourceMappingURL=constants.d.ts.map