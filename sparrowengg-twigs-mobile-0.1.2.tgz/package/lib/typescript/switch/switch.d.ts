import React from 'react';
import { View } from 'react-native';
import type { SwitchProps } from './types';
/** Toggle switch with animated thumb, supporting controlled and uncontrolled modes. */
export declare const Switch: React.ForwardRefExoticComponent<SwitchProps & React.RefAttributes<View>>;
//# sourceMappingURL=switch.d.ts.map