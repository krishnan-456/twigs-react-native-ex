import type { AvatarSize, AvatarSizeProp } from './types';
export interface AvatarGroupSizeConfig {
    /** Negative margin overlap between avatars (dp). */
    overlap: number;
    /** White border width around each avatar (dp). */
    borderWidth: number;
    /** Font size for the overflow "+N" label (dp). */
    overlayFontSize: number;
    /** Line height for the overflow "+N" label (dp). */
    overlayLineHeight: number;
    /** Letter spacing for the overflow "+N" label. */
    overlayLetterSpacing: number;
}
export declare const DEFAULT_AVATAR_GROUP_LIMIT = 0;
export declare const DEFAULT_AVATAR_GROUP_SIZE: AvatarSizeProp;
export declare const DEFAULT_AVATAR_GROUP_ROUNDED: AvatarSize;
export declare const AVATAR_GROUP_SIZE_CONFIG: Record<AvatarSizeProp, AvatarGroupSizeConfig>;
//# sourceMappingURL=avatar-group.constants.d.ts.map