export declare const avatarStyles: {
    avatarBase: {
        alignItems: "center";
        justifyContent: "center";
        overflow: "hidden";
        position: "relative";
    };
};
//# sourceMappingURL=styles.d.ts.map