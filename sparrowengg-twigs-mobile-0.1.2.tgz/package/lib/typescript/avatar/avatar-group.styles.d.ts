export declare const avatarGroupStyles: {
    group: {
        flexDirection: "row";
        alignItems: "center";
    };
    item: {
        zIndex: number;
        overflow: "hidden";
    };
    overflowOverlay: {
        alignItems: "center";
        justifyContent: "center";
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
};
//# sourceMappingURL=avatar-group.styles.d.ts.map