import type { AvatarSize } from './types';
/** Border radius for a given rounded variant. */
export declare const getAvatarBorderRadius: (rounded: AvatarSize) => number;
/** Extract initials from a full name (first + last). */
export declare const getFallbackInitials: (name: string) => string;
//# sourceMappingURL=helpers.d.ts.map