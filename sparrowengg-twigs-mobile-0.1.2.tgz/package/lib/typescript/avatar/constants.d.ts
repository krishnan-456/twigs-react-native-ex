import type { AvatarSize, AvatarSizeProp } from './types';
export declare const AVATAR_DIMENSIONS: Record<AvatarSizeProp, {
    width: number;
    height: number;
}>;
export declare const AVATAR_FONT_SIZES: Record<AvatarSizeProp, number>;
export declare const AVATAR_ANONYMOUS_BORDER_WIDTHS: Record<AvatarSizeProp, number>;
export declare const AVATAR_BORDER_RADII: Record<AvatarSize, number>;
export declare const DEFAULT_AVATAR_NAME = "?";
//# sourceMappingURL=constants.d.ts.map