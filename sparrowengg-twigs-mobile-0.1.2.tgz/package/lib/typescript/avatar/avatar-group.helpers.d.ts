import React from 'react';
import type { TextStyle, ViewStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { AvatarGroupProps } from './avatar-group.types';
import type { AvatarProps, AvatarSize, AvatarSizeProp } from './types';
export declare const isAvatarElement: (child: React.ReactNode) => child is React.ReactElement<AvatarProps>;
export declare const getAvatarChildren: (children: AvatarGroupProps["children"]) => React.ReactElement<AvatarProps>[];
/** Dynamic wrapper style for each avatar item in the group. */
export declare const getAvatarGroupItemStyles: (theme: TwigsTheme, size: AvatarSizeProp, rounded: AvatarSize, isFirst: boolean) => ViewStyle;
/** Typography for the overflow label rendered on top of the last avatar. */
export declare const getAvatarGroupOverlayTextStyles: (size: AvatarSizeProp) => TextStyle;
//# sourceMappingURL=avatar-group.helpers.d.ts.map