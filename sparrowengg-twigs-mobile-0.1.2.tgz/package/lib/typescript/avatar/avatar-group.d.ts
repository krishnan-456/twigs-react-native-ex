import React from 'react';
import { View } from 'react-native';
import type { AvatarGroupProps } from './avatar-group.types';
/** Overlapping avatar stack with optional "+N" overflow indicator. */
export declare const AvatarGroup: React.ForwardRefExoticComponent<AvatarGroupProps & React.RefAttributes<View>>;
//# sourceMappingURL=avatar-group.d.ts.map