import React from 'react';
import { View } from 'react-native';
import type { AvatarProps } from './types';
/** Displays a user avatar with image, initials fallback, or anonymous placeholder. */
export declare const Avatar: React.ForwardRefExoticComponent<AvatarProps & React.RefAttributes<View>>;
//# sourceMappingURL=avatar.d.ts.map