import React from 'react';
import { View } from 'react-native';
import type { TabsProps } from './types';
/** Root container for a tabbed interface. Manages active tab state. */
export declare const Tabs: React.ForwardRefExoticComponent<TabsProps & React.RefAttributes<View>>;
//# sourceMappingURL=tabs.d.ts.map