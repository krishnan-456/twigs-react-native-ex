export declare const styles: {
    root: {
        flexDirection: "column";
    };
    list: {
        width: "100%";
    };
    scrollContent: {
        flexGrow: number;
    };
    inner: {
        flexDirection: "row";
        alignItems: "stretch";
        position: "relative";
    };
    innerFitted: {
        flexDirection: "row";
        alignItems: "stretch";
        position: "relative";
        width: "100%";
    };
    trigger: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
    };
    fittedTrigger: {
        flex: number;
    };
    indicator: {
        position: "absolute";
        bottom: number;
        left: number;
    };
    disabled: {
        opacity: number;
    };
};
//# sourceMappingURL=styles.d.ts.map