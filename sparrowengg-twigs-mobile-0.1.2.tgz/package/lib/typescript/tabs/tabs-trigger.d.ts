import React from 'react';
import type { TabsTriggerProps } from './types';
/** Individual tab button within a TabsList. */
export declare const TabsTrigger: React.ForwardRefExoticComponent<TabsTriggerProps & React.RefAttributes<import("react-native").View>>;
//# sourceMappingURL=tabs-trigger.d.ts.map