import React from 'react';
import { View } from 'react-native';
import type { TabsContentProps } from './types';
/** Content panel shown when its matching tab trigger is active. */
export declare const TabsContent: React.ForwardRefExoticComponent<TabsContentProps & React.RefAttributes<View>>;
//# sourceMappingURL=tabs-content.d.ts.map