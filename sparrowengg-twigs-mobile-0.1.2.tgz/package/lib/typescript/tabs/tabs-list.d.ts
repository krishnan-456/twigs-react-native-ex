import React from 'react';
import { View } from 'react-native';
import type { TabsListProps } from './types';
/** Horizontal row of tab triggers with an animated active indicator. */
export declare const TabsList: React.ForwardRefExoticComponent<TabsListProps & React.RefAttributes<View>>;
//# sourceMappingURL=tabs-list.d.ts.map