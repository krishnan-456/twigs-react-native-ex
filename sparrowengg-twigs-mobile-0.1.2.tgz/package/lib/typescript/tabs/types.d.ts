import type { ViewProps, PressableProps } from 'react-native';
import type { CommonStyleProps, BaseAccessibilityProps } from '../utils';
/** Size variant for tab triggers. */
export type TabsSize = 'md' | 'lg';
/** Color variant for the active tab indicator and text. */
export type TabsVariant = 'primary' | 'dark';
/** Props for the root Tabs container. */
export interface TabsProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Currently active tab value (controlled). */
    value?: string;
    /** Default active tab value (uncontrolled). */
    defaultValue?: string;
    /** Called when the active tab changes. */
    onValueChange?: (value: string) => void;
}
/** Props for the TabsList container that holds tab triggers. */
export interface TabsListProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Size variant for tab triggers. */
    size?: TabsSize;
    /** Color variant for the active indicator and text. */
    variant?: TabsVariant;
    /** Whether the tab triggers can scroll horizontally (default: true). When false, triggers share equal width. */
    scrollable?: boolean;
}
/** Props for an individual tab trigger button. */
export interface TabsTriggerProps extends Omit<PressableProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Unique value identifying this tab — must match a TabsContent value. */
    value: string;
    /** Whether this trigger is disabled. */
    disabled?: boolean;
    /** Content to render inside the trigger. */
    children: React.ReactNode;
}
/** Props for a tab content panel. */
export interface TabsContentProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Value matching a TabsTrigger — panel is visible when this tab is active. */
    value: string;
    /** Whether to keep the content mounted when the tab is inactive. */
    forceMount?: boolean;
    /** Content to render inside the panel. */
    children: React.ReactNode;
}
//# sourceMappingURL=types.d.ts.map