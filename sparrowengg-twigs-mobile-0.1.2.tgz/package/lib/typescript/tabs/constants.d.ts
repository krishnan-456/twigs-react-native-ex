import type { TabsSize, TabsVariant } from './types';
interface SizeConfig {
    height: number;
    paddingHorizontal: number;
    fontSize: number;
    lineHeight: number;
}
export declare const SIZE_CONFIG: Record<TabsSize, SizeConfig>;
export declare const DEFAULT_SIZE: TabsSize;
export declare const DEFAULT_VARIANT: TabsVariant;
export declare const INDICATOR_HEIGHT = 2;
export declare const SLIDE_DURATION = 200;
export declare const SLIDE_TIMING_CONFIG: {
    readonly duration: 200;
    readonly easing: import("react-native-reanimated").EasingFunction;
};
export {};
//# sourceMappingURL=constants.d.ts.map