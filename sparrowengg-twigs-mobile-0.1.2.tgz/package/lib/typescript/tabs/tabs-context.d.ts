import type { TabsSize, TabsVariant } from './types';
export interface TabsContextValue {
    /** Currently active tab value. */
    activeValue: string;
    /** Called when a trigger is pressed. */
    onSelect: (value: string) => void;
}
export interface TabsListContextValue {
    /** Size variant applied to triggers. */
    size: TabsSize;
    /** Color variant applied to triggers and indicator. */
    variant: TabsVariant;
    /** Report measured width for indicator positioning. */
    reportWidth: (value: string, width: number) => void;
    /** Whether the tab list is scrollable. */
    scrollable: boolean;
}
declare const TabsContext: import("react").Context<TabsContextValue | null>;
declare const TabsListContext: import("react").Context<TabsListContextValue | null>;
export declare function useTabsContext(): TabsContextValue;
export declare function useTabsListContext(): TabsListContextValue;
export { TabsContext, TabsListContext };
//# sourceMappingURL=tabs-context.d.ts.map