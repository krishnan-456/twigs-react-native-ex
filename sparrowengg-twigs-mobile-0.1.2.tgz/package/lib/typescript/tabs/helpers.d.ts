import React from 'react';
import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { TabsSize, TabsVariant } from './types';
export interface TriggerMeta {
    value: string;
    disabled: boolean;
}
export declare function getTriggerInfo(children: React.ReactNode): TriggerMeta[];
export declare const TRIGGER_SIZE_STYLES: Record<TabsSize, ViewStyle>;
export declare function getTriggerTextStyles(theme: TwigsTheme, variant: TabsVariant, isActive: boolean, disabled: boolean, size: TabsSize): TextStyle;
export declare function getIndicatorColorStyles(theme: TwigsTheme, variant: TabsVariant): ViewStyle;
//# sourceMappingURL=helpers.d.ts.map