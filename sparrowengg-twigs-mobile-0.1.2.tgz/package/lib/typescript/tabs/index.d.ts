export { Tabs } from './tabs';
export { TabsList } from './tabs-list';
export { TabsTrigger } from './tabs-trigger';
export { TabsContent } from './tabs-content';
export type { TabsProps, TabsListProps, TabsTriggerProps, TabsContentProps, TabsSize, TabsVariant, } from './types';
//# sourceMappingURL=index.d.ts.map