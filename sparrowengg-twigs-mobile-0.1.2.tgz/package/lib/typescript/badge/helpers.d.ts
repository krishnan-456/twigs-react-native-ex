import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { BadgeSize, BadgeColor, BadgeRounded } from './types';
export declare function getSizeStyles(size: BadgeSize, rounded: BadgeRounded): ViewStyle;
export declare function getColorStyles(theme: TwigsTheme, color: BadgeColor): ViewStyle;
export declare function getTextStyles(theme: TwigsTheme, color: BadgeColor, size: BadgeSize): TextStyle;
export declare function getIconSize(size: BadgeSize): number;
export declare function getIconColor(theme: TwigsTheme, color: BadgeColor): string;
//# sourceMappingURL=helpers.d.ts.map