export declare const styles: {
    container: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        alignSelf: "flex-start";
    };
    contentWrap: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        paddingHorizontal: number;
    };
    sideElement: {
        alignItems: "center";
        justifyContent: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map