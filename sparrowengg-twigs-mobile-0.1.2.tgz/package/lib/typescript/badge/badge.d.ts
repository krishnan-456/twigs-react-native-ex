import React from 'react';
import { View } from 'react-native';
import type { BadgeProps } from './types';
/** Compact pill-shaped element for labels, tags, and status indicators. */
export declare const Badge: React.ForwardRefExoticComponent<BadgeProps & React.RefAttributes<View>>;
//# sourceMappingURL=badge.d.ts.map