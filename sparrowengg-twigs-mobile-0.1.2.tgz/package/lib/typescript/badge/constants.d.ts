import type { BadgeSize, BadgeColor, BadgeRounded } from './types';
interface SizeConfig {
    height: number;
    paddingHorizontal: number;
    fontSize: number;
    lineHeight: number;
    iconSize: number;
    gap: number;
}
export declare const SIZE_CONFIG: Record<BadgeSize, SizeConfig>;
export declare const ROUNDED_RADII: Record<BadgeRounded, number>;
/** `null` means the background is computed at runtime (e.g. primary uses an alpha overlay). */
export declare const COLOR_BG_MAP: Record<BadgeColor, string | null>;
export declare const PRIMARY_BG_OPACITY = 0.08;
export declare const COLOR_TEXT_MAP: Record<BadgeColor, string>;
export declare const COLOR_BORDER_MAP: Record<BadgeColor, string | null>;
export declare const DEFAULT_SIZE: BadgeSize;
export declare const DEFAULT_COLOR: BadgeColor;
export declare const DEFAULT_ROUNDED: BadgeRounded;
export {};
//# sourceMappingURL=constants.d.ts.map