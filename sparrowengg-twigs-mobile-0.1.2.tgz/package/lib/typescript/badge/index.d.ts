export { Badge } from './badge';
export type { BadgeProps, BadgeSize, BadgeColor, BadgeRounded } from './types';
//# sourceMappingURL=index.d.ts.map