import type { TwigsTheme } from '../theme';
import type { LoaderColor } from './types';
export interface LoaderColorPair {
    bg: string;
    fg: string;
}
/** Resolves a LoaderColor preset to background (track/ring) and foreground (dot/arc) hex values. */
export declare function getLoaderColors(theme: TwigsTheme, color: LoaderColor): LoaderColorPair;
//# sourceMappingURL=helpers.d.ts.map