import type { LineLoaderSize, CircleLoaderSize } from './types';
export declare const LINE_LOADER_DIMENSIONS: Record<LineLoaderSize, {
    width: number;
    height: number;
}>;
export declare const CIRCLE_LOADER_DIAMETERS: Record<CircleLoaderSize, number>;
export declare const CIRCLE_STROKE_WIDTHS: Record<CircleLoaderSize, number>;
//# sourceMappingURL=constants.d.ts.map