import React from 'react';
import { View } from 'react-native';
import type { LineLoaderProps } from './types';
/** Animated horizontal line loader with a sliding dot indicator. */
export declare const LineLoader: React.ForwardRefExoticComponent<LineLoaderProps & React.RefAttributes<View>>;
//# sourceMappingURL=line-loader.d.ts.map