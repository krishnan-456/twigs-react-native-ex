import React from 'react';
import { View } from 'react-native';
import type { CircleLoaderProps } from './types';
/** Animated circular spinner using SVG arcs with a rotating quarter-circle indicator. */
export declare const CircleLoader: React.ForwardRefExoticComponent<CircleLoaderProps & React.RefAttributes<View>>;
//# sourceMappingURL=circle-loader.d.ts.map