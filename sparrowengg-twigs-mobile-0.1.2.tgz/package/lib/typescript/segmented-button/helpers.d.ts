import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { SegmentedButtonRounded } from './types';
export declare function getContainerStyles(theme: TwigsTheme, rounded: SegmentedButtonRounded, fullWidth: boolean): ViewStyle;
export declare function getIndicatorStyles(theme: TwigsTheme, rounded: SegmentedButtonRounded): ViewStyle;
export declare function getSegmentTextStyles(theme: TwigsTheme, selected: boolean): TextStyle;
export declare function getSegmentPressedStyles(theme: TwigsTheme, rounded: SegmentedButtonRounded): ViewStyle;
//# sourceMappingURL=helpers.d.ts.map