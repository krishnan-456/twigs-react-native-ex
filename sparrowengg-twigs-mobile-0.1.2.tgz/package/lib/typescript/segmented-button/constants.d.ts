import type { SegmentedButtonRounded } from './types';
export declare const CONTAINER_HEIGHT = 48;
export declare const SEGMENT_PADDING_HORIZONTAL = 20;
export declare const SEGMENT_FONT_SIZE = 14;
export declare const SEGMENT_LINE_HEIGHT = 20;
export declare const SEGMENT_LETTER_SPACING = 0.2;
export declare const SELECTED_BORDER_WIDTH = 1.5;
export declare const SELECTED_SHADOW: {
    readonly shadowOffset: {
        readonly width: 1;
        readonly height: 1;
    };
    readonly shadowOpacity: 0.04;
    readonly shadowRadius: 5;
};
export declare const SELECTED_ELEVATION = 2;
export declare const CONTAINER_BG_OPACITY = 0.08;
export declare const ROUNDED_RADII: Record<SegmentedButtonRounded, number>;
export declare const DEFAULT_ROUNDED: SegmentedButtonRounded;
export declare const SLIDE_DURATION = 200;
//# sourceMappingURL=constants.d.ts.map