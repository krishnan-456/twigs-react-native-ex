export { SegmentedButton } from './segmented-button';
export type { SegmentedButtonProps, SegmentedButtonOption, SegmentedButtonRounded } from './types';
//# sourceMappingURL=index.d.ts.map