import React from 'react';
import { View } from 'react-native';
import type { SegmentedButtonProps } from './types';
/** Horizontal group of mutually exclusive options with an animated sliding indicator. */
export declare const SegmentedButton: React.ForwardRefExoticComponent<SegmentedButtonProps & React.RefAttributes<View>>;
//# sourceMappingURL=segmented-button.d.ts.map