export declare const styles: {
    container: {
        flexDirection: "row";
        alignItems: "center";
        overflow: "hidden";
    };
    indicator: {
        position: "absolute";
        top: number;
        bottom: number;
    };
    segment: {
        flex: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        alignSelf: "stretch";
        paddingHorizontal: number;
    };
    disabled: {
        opacity: number;
    };
};
//# sourceMappingURL=styles.d.ts.map