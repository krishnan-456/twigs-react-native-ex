import React from 'react';
import { Text as RNText } from 'react-native';
import type { TextProps } from './types';
/** Themed text component with typography, spacing, and truncation props. */
export declare const Text: React.ForwardRefExoticComponent<TextProps & React.RefAttributes<RNText>>;
//# sourceMappingURL=text.d.ts.map