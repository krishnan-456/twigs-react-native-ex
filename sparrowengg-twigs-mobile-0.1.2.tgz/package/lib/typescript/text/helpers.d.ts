import type { TextStyle } from 'react-native';
import type { ThemeFonts } from '../theme/default-theme';
import type { TextWeight, TextProps } from './types';
/** Priority: weight (theme alias) › fontFamily/fontWeight (explicit) › theme default. */
export declare const resolveFontStyle: (themeFonts: ThemeFonts, options: {
    weight?: TextWeight;
    fontFamily?: string;
    fontWeight?: TextProps["fontWeight"];
}) => Pick<TextStyle, "fontFamily" | "fontWeight">;
//# sourceMappingURL=helpers.d.ts.map