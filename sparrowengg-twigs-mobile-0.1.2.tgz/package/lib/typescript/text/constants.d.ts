export declare const DEFAULT_FONT_SIZE = 14;
//# sourceMappingURL=constants.d.ts.map