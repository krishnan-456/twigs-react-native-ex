import React, { ReactNode } from 'react';
import { TwigsTheme } from '../theme/default-theme';
/** Recursively makes all properties optional — used for partial theme overrides. */
export type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};
export declare const ThemeContext: React.Context<TwigsTheme>;
export interface TwigsProviderProps {
    /** Partial theme overrides deep-merged with the default theme. */
    theme?: DeepPartial<TwigsTheme>;
    children: ReactNode;
}
/** Provides the Twigs theme context to all child components. */
export declare function TwigsProvider({ theme: customTheme, children }: TwigsProviderProps): React.JSX.Element;
/** Returns the current Twigs theme from the nearest TwigsProvider. */
export declare function useTheme(): TwigsTheme;
//# sourceMappingURL=theme-context.d.ts.map