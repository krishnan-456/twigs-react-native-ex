export { TwigsProvider, useTheme, type TwigsProviderProps, type DeepPartial, } from './theme-context';
//# sourceMappingURL=index.d.ts.map