import type { ButtonSize, ButtonVariant } from './types';
export interface SizeConfig {
    paddingHorizontal: number;
    height: number;
    width: number | 'auto';
    borderRadius: number;
    fontSize: number;
    iconSize: number;
    labelPaddingHorizontal: number;
}
export interface ColorConfig {
    background: string;
    text: string;
    pressedBackground: string;
    pressedText: string;
    border?: string;
    pressedBorder?: string;
}
export interface ColorConfigMap {
    [key: string]: {
        [variant in ButtonVariant]: ColorConfig;
    };
}
export declare const getButtonSizeConfig: (size: ButtonSize, isIcon: boolean) => SizeConfig;
export declare const ICON_SIZES: Record<ButtonSize, number>;
export declare const ICON_ONLY_SIZES: Record<ButtonSize, number>;
export declare const ICON_SPACING: Record<ButtonSize, number>;
export declare const LINE_LOADER_WIDTH_MAP: Record<ButtonSize, number>;
export declare const OUTLINE_BORDER_WIDTH: Record<ButtonSize, number>;
//# sourceMappingURL=constants.d.ts.map