import type { TextStyle, ViewStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { LoaderColor, LineLoaderSize, CircleLoaderSize } from '../loader';
import type { ButtonSize, ButtonColor, ButtonVariant } from './types';
export declare const getSizeStyles: (size: ButtonSize, isIcon: boolean) => ViewStyle;
export declare const getColorStyles: (color: ButtonColor, variant: ButtonVariant, theme: TwigsTheme) => ViewStyle;
export declare const getButtonStyles: ({ size, color, variant, isIcon, theme, }: {
    size: ButtonSize;
    color: ButtonColor;
    variant: ButtonVariant;
    isIcon: boolean;
    theme: TwigsTheme;
}) => ViewStyle;
export declare const getTextColor: (color: ButtonColor, variant: ButtonVariant, theme: TwigsTheme) => string;
export declare const getPressedTextColor: (color: ButtonColor, variant: ButtonVariant, theme: TwigsTheme) => string;
export declare const getButtonTextStyles: ({ size, color, variant, theme, pressed, }: {
    size: ButtonSize;
    color: ButtonColor;
    variant: ButtonVariant;
    theme: TwigsTheme;
    pressed?: boolean;
}) => TextStyle;
export declare const getIconSize: (size: ButtonSize, position: "left" | "right" | "center") => number;
export declare const getIconContainerStyles: ({ position, size, }: {
    position: "left" | "right" | "center";
    size: ButtonSize;
}) => ViewStyle;
/**
 * Maps a button color+variant combination to the appropriate LoaderColor.
 * Uses a compound key lookup first (e.g. 'primary-solid' → 'bright'),
 * then falls back to a simple color→loader mapping.
 */
export declare const getLoaderColorFromButton: (color: ButtonColor, variant: ButtonVariant) => LoaderColor;
export declare const getLineLoaderSizeFromButton: (size: ButtonSize) => LineLoaderSize;
export declare const getLineLoaderWidthFromButton: (size: ButtonSize) => number;
export declare const getCircleLoaderSizeFromButton: (size: ButtonSize) => CircleLoaderSize;
export declare const getPressedStyle: (color: ButtonColor, variant: ButtonVariant, theme: TwigsTheme) => ViewStyle;
export declare const getButtonLoaderMargin: (size: ButtonSize) => number;
//# sourceMappingURL=helpers.d.ts.map