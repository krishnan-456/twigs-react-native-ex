import React from 'react';
import { View } from 'react-native';
import type { ButtonProps } from './types';
/**
 * Pressable button with multiple size, color, and variant presets.
 * Supports loading state, left/right icons, and icon-only mode.
 */
export declare const Button: React.ForwardRefExoticComponent<ButtonProps & React.RefAttributes<View>>;
//# sourceMappingURL=button.d.ts.map