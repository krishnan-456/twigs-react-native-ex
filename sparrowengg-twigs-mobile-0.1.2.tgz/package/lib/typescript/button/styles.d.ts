export declare const buttonStyles: {
    buttonBase: {
        borderRadius: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
    };
    buttonDisabled: {
        opacity: number;
    };
};
//# sourceMappingURL=styles.d.ts.map