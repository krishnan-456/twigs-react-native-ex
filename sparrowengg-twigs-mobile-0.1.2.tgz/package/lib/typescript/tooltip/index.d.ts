export { Tooltip } from './tooltip';
export type { TooltipProps, TooltipSide, TooltipAlign } from './types';
//# sourceMappingURL=index.d.ts.map