import type { TooltipSide } from './types';
export declare const TOOLTIP_CONFIG: {
    paddingHorizontal: number;
    paddingVertical: number;
    fontSize: number;
    fontFamily: "medium";
    lineHeight: number;
    borderRadius: number;
    maxWidth: number;
};
export declare const ARROW_SIZE: {
    width: number;
    height: number;
};
/** Arrow inset from tooltip edge for start/end alignments (Figma: 8dp). */
export declare const ARROW_EDGE_OFFSET = 8;
export declare const DEFAULT_SIDE: TooltipSide;
export declare const DEFAULT_SIDE_OFFSET = 6;
export declare const ANIMATION_DURATION = 150;
//# sourceMappingURL=constants.d.ts.map