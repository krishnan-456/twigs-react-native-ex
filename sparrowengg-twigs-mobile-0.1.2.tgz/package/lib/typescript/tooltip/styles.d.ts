export declare const styles: {
    overlay: {
        zIndex: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    backdropPressable: {
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    contentWrapper: {
        position: "absolute";
    };
    arrowContainer: {
        position: "absolute";
    };
};
//# sourceMappingURL=styles.d.ts.map