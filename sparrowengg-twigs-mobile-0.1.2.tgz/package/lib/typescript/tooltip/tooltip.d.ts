import React from 'react';
import { View } from 'react-native';
import type { TooltipProps } from './types';
/** Floating content bubble anchored to a trigger element with arrow pointer. */
export declare const Tooltip: React.ForwardRefExoticComponent<TooltipProps & React.RefAttributes<View>>;
//# sourceMappingURL=tooltip.d.ts.map