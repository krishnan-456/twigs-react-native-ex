import type { Placement } from '@floating-ui/react-native';
import type { TextStyle, ViewStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { TooltipSide, TooltipAlign } from './types';
export declare function toPlacement(side: TooltipSide, align: TooltipAlign): Placement;
/**
 * Calculates the cross-axis shift needed for the tooltip's arrow to point at the trigger's center,
 * used for left/right sides with start/end alignment.
 */
export declare function getCrossAxisOffset(side: TooltipSide, align: TooltipAlign, refSize: number): number;
export declare function getContentStyles(theme: TwigsTheme): ViewStyle;
export declare function getTextStyles(theme: TwigsTheme): TextStyle;
export declare function getArrowPath(side: TooltipSide): string;
/** Swaps width/height for left/right sides since the arrow rotates 90°. */
export declare function getArrowDimensions(side: TooltipSide): {
    width: number;
    height: number;
};
/**
 * For `center` alignment, uses floating-ui's computed coordinate.
 * For `start`/`end`, pins the arrow at `ARROW_EDGE_OFFSET` from the
 * corresponding tooltip edge (Figma spec: 8dp).
 */
export declare function getArrowPositionStyle(side: TooltipSide, align: TooltipAlign, arrowDims: {
    width: number;
    height: number;
}, arrowMiddleware: {
    x?: number;
    y?: number;
} | undefined): ViewStyle;
//# sourceMappingURL=helpers.d.ts.map