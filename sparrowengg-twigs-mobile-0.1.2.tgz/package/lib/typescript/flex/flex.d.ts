import React from 'react';
import { View } from 'react-native';
import type { FlexProps } from './types';
/** Flexbox layout container with direction, alignment, and spacing shorthand props. */
export declare const Flex: React.ForwardRefExoticComponent<FlexProps & React.RefAttributes<View>>;
//# sourceMappingURL=flex.d.ts.map