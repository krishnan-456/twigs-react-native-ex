export { Flex } from './flex';
export type { FlexProps } from './types';
//# sourceMappingURL=index.d.ts.map