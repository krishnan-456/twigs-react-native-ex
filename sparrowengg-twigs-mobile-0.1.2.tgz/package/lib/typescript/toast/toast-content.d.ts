import React from 'react';
import type { ToastContentProps } from './types';
/**
 * Visual content renderer for a single toast. Consumed by ToastItem.
 * Not exported from the public API — consumers interact via toast() and ToastProvider.
 */
export declare const ToastContent: ({ title, description, variant: variantProp, icon, action, }: ToastContentProps) => React.JSX.Element;
//# sourceMappingURL=toast-content.d.ts.map