export declare const styles: {
    overlay: {
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    gestureRoot: {
        flex: number;
    };
    stackContainer: {
        width: "100%";
    };
    toastWrapper: {
        width: "100%";
        alignItems: "center";
    };
    container: {
        flexDirection: "row";
        alignItems: "center";
    };
    contentSection: {
        flexDirection: "row";
        flex: number;
        alignItems: "center";
        gap: number;
    };
    iconContainer: {
        alignItems: "center";
        justifyContent: "center";
    };
    textContainer: {
        flex: number;
    };
    title: {
        flexShrink: number;
    };
    description: {
        flexShrink: number;
    };
    actionContainer: {
        alignItems: "center";
        justifyContent: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map