import React from 'react';
import type { ToastContainerProps } from './types';
export declare const ToastContainer: (props: ToastContainerProps) => React.JSX.Element;
//# sourceMappingURL=toast-container.d.ts.map