import type { ToastVariant, ToastPosition } from './types';
interface VariantColorConfig {
    background: string;
    text: string;
    icon: string;
    actionText: string;
}
export declare const VARIANT_COLORS: Record<ToastVariant, VariantColorConfig>;
export declare const TOAST_ICON_SIZE = 24;
export declare const TOAST_BORDER_RADIUS = 8;
export declare const TOAST_PADDING_HORIZONTAL = 16;
export declare const TOAST_PADDING_VERTICAL = 12;
export declare const TOAST_CONTAINER_GAP = 16;
export declare const TOAST_CONTENT_GAP = 8;
export declare const TOAST_MAX_WIDTH = 400;
export declare const TOAST_MIN_HEIGHT = 48;
export declare const TOAST_TITLE_FONT_SIZE = 14;
export declare const TOAST_TITLE_LINE_HEIGHT = 20;
export declare const TOAST_DESCRIPTION_FONT_SIZE = 12;
export declare const TOAST_DESCRIPTION_LINE_HEIGHT = 16;
export declare const DEFAULT_VARIANT: ToastVariant;
export declare const DEFAULT_DURATION = 4000;
export declare const DEFAULT_POSITION: ToastPosition;
export declare const DEFAULT_MAX_TOASTS = 3;
export declare const DEFAULT_GAP = 8;
export declare const DEFAULT_OFFSET = 40;
export declare const ANIMATION_DURATION = 300;
export declare const SWIPE_THRESHOLD = 24;
export declare const SWIPE_ELASTIC_RESISTANCE = 0.4;
export declare const SWIPE_DISMISS_OFFSET = -300;
export declare const ENTRY_SPRING_CONFIG: {
    damping: number;
    stiffness: number;
    mass: number;
};
export declare const PAN_ACTIVE_OFFSET_Y: [number, number];
export declare const PAN_FAIL_OFFSET_X: [number, number];
export declare const POSITION_STYLES: Record<ToastPosition, {
    vertical: 'top' | 'bottom';
}>;
export {};
//# sourceMappingURL=constants.d.ts.map