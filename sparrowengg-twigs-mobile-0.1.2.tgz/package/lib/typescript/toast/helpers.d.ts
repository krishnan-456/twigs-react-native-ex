import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { ToastVariant, ToastPosition } from './types';
export declare function generateToastId(): string;
export declare function getVariantContainerStyles(theme: TwigsTheme, variant: ToastVariant): ViewStyle;
export declare function getIconColor(theme: TwigsTheme, variant: ToastVariant): string;
export declare function getBackgroundColor(theme: TwigsTheme, variant: ToastVariant): string;
export declare function getTitleStyles(theme: TwigsTheme, variant: ToastVariant): TextStyle;
export declare function getDescriptionStyles(theme: TwigsTheme, variant: ToastVariant): TextStyle;
/**
 * Applies elastic resistance to a swipe distance (Reanimated worklet).
 * Returns a dampened value that decreases progressively as distance grows.
 */
export declare function elasticResistance(distance: number): number;
export declare function getPositionContainerStyle(position: ToastPosition, offset: number): ViewStyle;
//# sourceMappingURL=helpers.d.ts.map