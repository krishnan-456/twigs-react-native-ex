import React from 'react';
import type { ToastProviderProps } from './types';
/**
 * Provides toast infrastructure for the app. Must be placed inside TwigsProvider
 * so toast renderers can access the theme.
 *
 * Manages the toast queue and renders stacked toast containers per position.
 */
export declare const ToastProvider: {
    ({ children, defaultPosition, defaultDuration, maxToasts, gap, offset, }: ToastProviderProps): React.JSX.Element;
    displayName: string;
};
//# sourceMappingURL=toast-provider.d.ts.map