import React from 'react';
import type { ToastItemProps } from './types';
export declare const ToastItem: React.NamedExoticComponent<ToastItemProps>;
//# sourceMappingURL=toast-item.d.ts.map