import React from 'react';
import type { ToastIconProps, ToastInfoIconProps } from './types';
/** Filled check-circle icon for success/default variants. */
export declare const CheckCircleFilledIcon: ({ size, color }: ToastIconProps) => React.JSX.Element;
/** Filled alert-triangle icon for error variant. */
export declare const AlertFilledIcon: ({ size, color }: ToastIconProps) => React.JSX.Element;
/** Filled info-circle icon with inner cutout color for the "i" glyph. */
export declare const InfoCircleFilledIcon: ({ size, color, innerColor }: ToastInfoIconProps) => React.JSX.Element;
export declare const VARIANT_ICONS: Record<string, React.FC<ToastIconProps>>;
//# sourceMappingURL=icons.d.ts.map