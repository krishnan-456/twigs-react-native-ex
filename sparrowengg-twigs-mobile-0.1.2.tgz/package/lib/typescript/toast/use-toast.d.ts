import type { ToastOptions, ToastContextType, UseToastReturn } from './types';
export declare const ToastContext: import("react").Context<ToastContextType | null>;
/** Returns the toast context — throws if called outside ToastProvider. */
export declare function useToastContext(): ToastContextType;
type ShorthandArg = string | Omit<ToastOptions, 'variant'>;
/** React hook providing the full toast API — must be used inside ToastProvider */
export declare function useToast(): UseToastReturn;
declare let globalAdd: ToastContextType['add'] | null;
declare let globalDismiss: ToastContextType['dismiss'] | null;
declare let globalUpdate: ToastContextType['update'] | null;
/** Registers global toast handlers — called internally by ToastProvider on mount. */
export declare function setGlobalToastHandlers(add: typeof globalAdd, dismiss: typeof globalDismiss, update: typeof globalUpdate): void;
declare function showToast(options: ToastOptions): {
    id: string;
    dismiss: () => void;
};
/**
 * Imperative toast API — works inside and outside React components.
 *
 * @example
 * toast({ title: 'Hello', variant: 'success' });
 * toast.secondary('Info');
 * toast.success('Saved!');
 * toast.error('Failed!');
 * toast.warning('Careful');
 * toast.loading('Processing...');
 * toast.dismiss();
 * toast.dismiss(id);
 * toast.update(id, { title: 'Updated!' });
 */
export declare const toast: typeof showToast & {
    secondary: (arg: ShorthandArg) => {
        id: string;
        dismiss: () => void;
    };
    success: (arg: ShorthandArg) => {
        id: string;
        dismiss: () => void;
    };
    error: (arg: ShorthandArg) => {
        id: string;
        dismiss: () => void;
    };
    warning: (arg: ShorthandArg) => {
        id: string;
        dismiss: () => void;
    };
    loading: (arg: ShorthandArg) => {
        id: string;
        dismiss: () => void;
    };
    dismiss: (id?: string) => void | undefined;
    update: (id: string, options: Partial<ToastOptions>) => void | undefined;
};
export {};
//# sourceMappingURL=use-toast.d.ts.map