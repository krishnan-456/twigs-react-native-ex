export interface ThemeColors {
    primary: string;
    secondary: string;
    accent50: string;
    accent100: string;
    accent200: string;
    accent300: string;
    accent400: string;
    accent500: string;
    accent600: string;
    accent700: string;
    accent800: string;
    accent900: string;
    primary50: string;
    primary100: string;
    primary200: string;
    primary300: string;
    primary400: string;
    primary500: string;
    primary600: string;
    primary700: string;
    primary800: string;
    primary900: string;
    warning50: string;
    warning100: string;
    warning200: string;
    warning300: string;
    warning400: string;
    warning500: string;
    warning600: string;
    warning700: string;
    warning800: string;
    warning900: string;
    highlight50: string;
    highlight100: string;
    highlight200: string;
    highlight300: string;
    highlight400: string;
    highlight500: string;
    highlight600: string;
    highlight700: string;
    highlight800: string;
    highlight900: string;
    positive50: string;
    positive100: string;
    positive200: string;
    positive300: string;
    positive400: string;
    positive500: string;
    positive600: string;
    positive700: string;
    positive800: string;
    positive900: string;
    secondary50: string;
    secondary100: string;
    secondary200: string;
    secondary300: string;
    secondary400: string;
    secondary500: string;
    secondary600: string;
    secondary700: string;
    secondary800: string;
    secondary900: string;
    negative50: string;
    negative100: string;
    negative200: string;
    negative300: string;
    negative400: string;
    negative500: string;
    negative600: string;
    negative700: string;
    negative800: string;
    negative900: string;
    neutral50: string;
    neutral100: string;
    neutral200: string;
    neutral300: string;
    neutral400: string;
    neutral500: string;
    neutral600: string;
    neutral700: string;
    neutral800: string;
    neutral900: string;
    black50: string;
    black100: string;
    black200: string;
    black300: string;
    black400: string;
    black500: string;
    black600: string;
    black700: string;
    black800: string;
    black900: string;
    white50: string;
    white100: string;
    white200: string;
    white300: string;
    white400: string;
    white500: string;
    white600: string;
    white700: string;
    white800: string;
    white900: string;
}
/** Space tokens in dp (density-independent pixels). Key is a scale number. */
export interface ThemeSpace {
    [key: string]: number;
}
/** Font size tokens in dp. */
export interface ThemeFontSizes {
    xxs: number;
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    '2xl': number;
    '3xl': number;
    '4xl': number;
    '5xl': number;
}
/** Font family tokens. */
export interface ThemeFonts {
    regular: string;
    medium: string;
    bold: string;
}
/** Font weight tokens (React Native expects string values). */
export interface ThemeFontWeights {
    [key: string]: string;
}
/** Line height tokens in dp. */
export interface ThemeLineHeights {
    xxs: number;
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    '2xl': number;
    '3xl': number;
    '4xl': number;
}
/** Letter spacing tokens in dp. */
export interface ThemeLetterSpacings {
    [key: string]: number;
}
/** Component size tokens in dp. */
export interface ThemeSizes {
    [key: string]: number;
}
/** Border width tokens in dp. */
export interface ThemeBorderWidths {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
}
/** Border style tokens. */
export interface ThemeBorderStyles {
    [key: string]: string;
}
/** Border radius tokens in dp. `round` and `pill` use 9999. */
export interface ThemeRadii {
    none: number;
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    '2xl': number;
    '3xl': number;
    '4xl': number;
    round: number;
    pill: number;
}
/** Shadow tokens (React Native shadow objects serialised as strings). */
export interface ThemeShadows {
    [key: string]: string;
}
/** Z-index tokens. */
export interface ThemeZIndices {
    [key: string]: number;
}
/** Transition duration tokens in milliseconds. */
export interface ThemeTransitions {
    [key: string]: number;
}
/** Complete theme object consumed by all Twigs components via `useTheme()`. */
export interface TwigsTheme {
    colors: ThemeColors;
    space: ThemeSpace;
    fontSizes: ThemeFontSizes;
    fonts: ThemeFonts;
    fontWeights: ThemeFontWeights;
    lineHeights: ThemeLineHeights;
    letterSpacings: ThemeLetterSpacings;
    sizes: ThemeSizes;
    borderWidths: ThemeBorderWidths;
    borderStyles: ThemeBorderStyles;
    radii: ThemeRadii;
    shadows: ThemeShadows;
    zIndices: ThemeZIndices;
    transitions: ThemeTransitions;
}
/** Default theme values. All dimension tokens are React Native dp numbers. */
export declare const defaultTheme: TwigsTheme;
//# sourceMappingURL=default-theme.d.ts.map