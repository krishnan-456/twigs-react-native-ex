export { IconButton } from './icon-button';
export type { IconButtonProps, IconButtonSize, IconButtonColor, IconButtonVariant, IconButtonRounded, } from './types';
//# sourceMappingURL=index.d.ts.map