import type { IconButtonRounded, IconButtonSize } from './types';
import type { LoaderColor, LineLoaderSize, CircleLoaderSize } from '../loader';
export declare const ROUNDED_RADII: Record<IconButtonRounded, number>;
export declare const DEFAULT_ROUNDED: IconButtonRounded;
export interface IconButtonSizeConfig {
    /** Container height/width (square) in dp */
    containerSize: number;
    /** Icon size in dp */
    iconSize: number;
    /** Default squircle border radius in dp */
    borderRadius: number;
}
export declare const SIZE_CONFIG: Record<IconButtonSize, IconButtonSizeConfig>;
export declare const OUTLINE_BORDER_WIDTH: Record<IconButtonSize, number>;
export declare const DISABLED_OPACITY = 0.5;
export declare const LOADER_COLOR_MAP: Record<string, LoaderColor>;
export declare const LINE_LOADER_SIZE_MAP: Record<IconButtonSize, LineLoaderSize>;
export declare const LINE_LOADER_WIDTH_MAP: Record<IconButtonSize, number>;
export declare const CIRCLE_LOADER_SIZE_MAP: Record<IconButtonSize, CircleLoaderSize>;
//# sourceMappingURL=constants.d.ts.map