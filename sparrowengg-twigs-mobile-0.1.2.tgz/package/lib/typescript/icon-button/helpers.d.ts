import type { ViewStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
import type { LoaderColor } from '../loader';
import type { IconButtonColor, IconButtonVariant, IconButtonSize } from './types';
export declare const getIconButtonStyles: (color: IconButtonColor, variant: IconButtonVariant, size: IconButtonSize, theme: TwigsTheme) => ViewStyle;
export declare const getIconButtonPressedStyles: (color: IconButtonColor, variant: IconButtonVariant, theme: TwigsTheme) => ViewStyle;
export declare const getIconColor: (color: IconButtonColor, variant: IconButtonVariant, theme: TwigsTheme, pressed: boolean) => string;
export declare const getIconSize: (size: IconButtonSize) => number;
export declare const getLoaderColor: (color: IconButtonColor, variant: IconButtonVariant) => LoaderColor;
export declare const getLineLoaderSize: (size: IconButtonSize) => import("../loader").LineLoaderSize;
export declare const getLineLoaderWidth: (size: IconButtonSize) => number;
export declare const getCircleLoaderSize: (size: IconButtonSize) => import("../loader").CircleLoaderSize;
//# sourceMappingURL=helpers.d.ts.map