import React from 'react';
import { View } from 'react-native';
import type { IconButtonProps } from './types';
/** Icon-only pressable button with size, color, variant, and loading presets. */
export declare const IconButton: React.ForwardRefExoticComponent<IconButtonProps & React.RefAttributes<View>>;
//# sourceMappingURL=icon-button.d.ts.map