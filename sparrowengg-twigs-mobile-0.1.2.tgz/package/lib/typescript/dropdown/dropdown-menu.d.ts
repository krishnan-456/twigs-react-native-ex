import React from 'react';
import type { DropdownMenuProps } from './types';
/** Root compound component for a dropdown menu. Manages open state and size context. */
export declare const DropdownMenu: React.FC<DropdownMenuProps>;
//# sourceMappingURL=dropdown-menu.d.ts.map