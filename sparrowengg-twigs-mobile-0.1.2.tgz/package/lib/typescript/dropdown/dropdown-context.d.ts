import type { UseFloatingReturn } from '@floating-ui/react-native';
import type { DropdownMenuSize } from './types';
export interface DropdownMenuContextValue {
    /** Whether the dropdown is currently open. */
    isOpen: boolean;
    /** Toggle or set the open state. */
    onOpenChange: (open: boolean) => void;
    /** Size variant for items. */
    size: DropdownMenuSize;
    /** Floating UI refs for positioning (setReference, setFloating). */
    floatingRefs: UseFloatingReturn['refs'];
    /** Floating styles from useFloating. */
    floatingStyles: UseFloatingReturn['floatingStyles'];
}
declare const DropdownMenuContext: import("react").Context<DropdownMenuContextValue | null>;
export declare function useDropdownMenuContext(): DropdownMenuContextValue;
export { DropdownMenuContext };
//# sourceMappingURL=dropdown-context.d.ts.map