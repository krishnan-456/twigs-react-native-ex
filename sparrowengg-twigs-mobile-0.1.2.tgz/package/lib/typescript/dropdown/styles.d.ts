export declare const styles: {
    overlay: {
        zIndex: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    backdropPressable: {
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    contentWrapper: {
        position: "absolute";
    };
    item: {
        flexDirection: "row";
        alignItems: "center";
        gap: number;
    };
    itemTextContainer: {
        flex: number;
    };
    label: {
        justifyContent: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map