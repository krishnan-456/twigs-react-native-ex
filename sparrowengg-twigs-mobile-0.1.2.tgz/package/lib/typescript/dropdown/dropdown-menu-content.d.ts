import React from 'react';
import { View } from 'react-native';
import type { DropdownMenuContentProps } from './types';
/** Floating content container rendered in a Modal, anchored to the trigger. */
export declare const DropdownMenuContent: React.ForwardRefExoticComponent<DropdownMenuContentProps & React.RefAttributes<View>>;
//# sourceMappingURL=dropdown-menu-content.d.ts.map