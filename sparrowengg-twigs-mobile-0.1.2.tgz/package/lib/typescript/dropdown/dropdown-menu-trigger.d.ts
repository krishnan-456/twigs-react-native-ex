import React from 'react';
import { View } from 'react-native';
import type { DropdownMenuTriggerProps } from './types';
/** Pressable wrapper that toggles the dropdown open state when pressed. */
export declare const DropdownMenuTrigger: React.ForwardRefExoticComponent<DropdownMenuTriggerProps & React.RefAttributes<View>>;
//# sourceMappingURL=dropdown-menu-trigger.d.ts.map