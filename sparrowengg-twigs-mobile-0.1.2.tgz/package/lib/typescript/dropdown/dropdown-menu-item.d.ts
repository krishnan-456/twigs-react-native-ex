import React from 'react';
import type { DropdownMenuItemProps } from './types';
/** Individual action item within a DropdownMenuContent. */
export declare const DropdownMenuItem: React.ForwardRefExoticComponent<DropdownMenuItemProps & React.RefAttributes<import("react-native").View>>;
//# sourceMappingURL=dropdown-menu-item.d.ts.map