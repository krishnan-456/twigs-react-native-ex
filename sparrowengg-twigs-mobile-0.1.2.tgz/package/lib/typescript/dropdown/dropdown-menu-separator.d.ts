import React from 'react';
import { View } from 'react-native';
import type { DropdownMenuSeparatorProps } from './types';
/** Horizontal divider between menu items or sections. */
export declare const DropdownMenuSeparator: React.ForwardRefExoticComponent<DropdownMenuSeparatorProps & React.RefAttributes<View>>;
//# sourceMappingURL=dropdown-menu-separator.d.ts.map