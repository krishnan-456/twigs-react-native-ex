import type { ReactNode, ReactElement } from 'react';
import type { ViewProps, PressableProps } from 'react-native';
import type { CommonStyleProps, BaseAccessibilityProps } from '../utils';
/** Size variant for dropdown menu items. */
export type DropdownMenuSize = 'md' | 'lg';
/** Props for the root DropdownMenu compound component. */
export interface DropdownMenuProps {
    /** Size variant applied to all menu items. */
    size?: DropdownMenuSize;
    /** Controlled open state. */
    open?: boolean;
    /** Default open state (uncontrolled). */
    defaultOpen?: boolean;
    /** Called when the open state changes. */
    onOpenChange?: (open: boolean) => void;
    /** Children (Trigger + Content). */
    children: ReactNode;
}
/** Props for the dropdown trigger wrapper. */
export interface DropdownMenuTriggerProps extends Omit<PressableProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Content to render as the trigger. */
    children: ReactNode;
}
/** Props for the dropdown content container. */
export interface DropdownMenuContentProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Menu items, labels, and separators. */
    children: ReactNode;
}
/** Props for an individual dropdown menu item. */
export interface DropdownMenuItemProps extends Omit<PressableProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Item label text or custom content. */
    children: ReactNode;
    /** Whether this item is disabled. */
    disabled?: boolean;
    /** Called when the item is selected (pressed). */
    onSelect?: () => void;
    /** Icon rendered before the label. */
    leftElement?: ReactElement;
    /** Icon rendered after the label. */
    rightElement?: ReactElement;
    /** String value for accessibility (used as accessibilityLabel fallback). */
    textValue?: string;
}
/** Props for a dropdown menu section label. */
export interface DropdownMenuLabelProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Label text or custom content. */
    children: ReactNode;
}
/** Props for a dropdown menu separator. */
export interface DropdownMenuSeparatorProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Custom separator color. */
    color?: string;
}
//# sourceMappingURL=types.d.ts.map