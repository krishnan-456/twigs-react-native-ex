import React from 'react';
import { View } from 'react-native';
import type { DropdownMenuLabelProps } from './types';
/** Non-interactive section label within a DropdownMenuContent. */
export declare const DropdownMenuLabel: React.ForwardRefExoticComponent<DropdownMenuLabelProps & React.RefAttributes<View>>;
//# sourceMappingURL=dropdown-menu-label.d.ts.map