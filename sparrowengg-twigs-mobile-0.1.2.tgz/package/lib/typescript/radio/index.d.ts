export { Radio } from './radio';
export type { RadioProps, RadioSize } from './types';
//# sourceMappingURL=index.d.ts.map