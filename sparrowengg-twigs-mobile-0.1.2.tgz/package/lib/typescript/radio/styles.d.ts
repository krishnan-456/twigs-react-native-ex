import type { TwigsTheme } from '../theme';
export declare const createRadioStyles: (theme: TwigsTheme) => {
    outerCircle: {
        borderWidth: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    innerCircle: {
        backgroundColor: string;
    };
    labelContainer: {
        marginLeft: number;
    };
    container: {
        flexDirection: "row";
        alignItems: "center";
        alignSelf: "flex-start";
    };
    containerDisabled: {
        opacity: number;
    };
};
//# sourceMappingURL=styles.d.ts.map