import React from 'react';
import { View } from 'react-native';
import type { RadioProps } from './types';
/** Radio button with outer ring and inner dot, supporting an optional label. */
export declare const Radio: React.ForwardRefExoticComponent<RadioProps & React.RefAttributes<View>>;
//# sourceMappingURL=radio.d.ts.map