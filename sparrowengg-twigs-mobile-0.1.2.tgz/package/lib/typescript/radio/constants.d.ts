import type { RadioSize } from './types';
export interface RadioSizeConfig {
    outerSize: number;
    innerSize: number;
}
export declare const RADIO_SIZE_CONFIGS: Record<RadioSize, RadioSizeConfig>;
/** Resolved size config for a given radio size. */
export declare const getRadioSizeConfig: (size: RadioSize) => RadioSizeConfig;
//# sourceMappingURL=constants.d.ts.map