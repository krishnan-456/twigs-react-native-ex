import type { TextAreaSize } from './types';
export interface TextAreaSizeConfig {
    /** Border radius in dp. */
    borderRadius: number;
    /** Placeholder / input text font size in dp. */
    fontSize: number;
    /** Horizontal padding inside the textarea in dp. */
    paddingHorizontal: number;
    /** Vertical padding inside the textarea in dp. */
    paddingVertical: number;
    /** Font size for the label text above the textarea. */
    labelFontSize: number;
    /** Line height for label text. */
    labelLineHeight: number;
    /** Letter spacing for label text. */
    labelLetterSpacing: number;
    /** Line height for placeholder / input text. */
    inputLineHeight: number;
}
/** Default number of visible text rows. */
export declare const DEFAULT_ROWS = 3;
/** Resolved size config for a given text-area size. */
export declare const getSizeConfig: (size: TextAreaSize) => TextAreaSizeConfig;
//# sourceMappingURL=constants.d.ts.map