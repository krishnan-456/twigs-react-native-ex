/** Static layout styles — no theme colors here. Theme-dependent styles go in the component. */
export declare const styles: {
    container: {
        position: "relative";
        width: "100%";
    };
    fullWidth: {
        width: "100%";
    };
    inputWrapper: {
        position: "relative";
        width: "100%";
        borderWidth: number;
        borderStyle: "solid";
    };
    textInput: {
        outlineStyle?: string | undefined;
        outlineWidth?: number | undefined;
        outlineColor?: string | undefined;
        flex: number;
        margin: number;
        padding: number;
        borderWidth: number;
        backgroundColor: string;
        textAlignVertical: "top";
    };
    labelRow: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    labelWithIndicator: {
        flexDirection: "row";
        alignItems: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map