import React from 'react';
import { TextInput as RNTextInput } from 'react-native';
import type { TextAreaProps } from './types';
/** Themed multi-line text area with auto-grow, label, error state, and character count. */
export declare const TextArea: React.ForwardRefExoticComponent<TextAreaProps & React.RefAttributes<RNTextInput>>;
//# sourceMappingURL=text-area.d.ts.map