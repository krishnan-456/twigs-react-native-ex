export { TextArea } from './text-area';
export type { TextAreaProps, TextAreaSize, TextAreaVariant } from './types';
//# sourceMappingURL=index.d.ts.map