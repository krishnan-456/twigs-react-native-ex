import type { ReactElement, ReactNode } from 'react';
import type { TextInputProps as RNTextInputProps } from 'react-native';
import type { CommonStyleProps, BaseAccessibilityProps } from '../utils';
export type TextAreaSize = 'lg' | 'xl';
export type TextAreaVariant = 'default' | 'filled';
export interface TextAreaProps extends Omit<RNTextInputProps, 'style' | 'multiline'>, CommonStyleProps, BaseAccessibilityProps {
    /** Size preset controlling font size, border radius, and padding. @default 'lg' */
    size?: TextAreaSize;
    /** Visual variant. @default 'default' */
    variant?: TextAreaVariant;
    /** Number of visible text lines. Sets the initial height. @default 3 */
    rows?: number;
    /** Maximum number of rows before scrolling when autoGrow is enabled. */
    maxRows?: number;
    /** Whether the textarea automatically grows with content. @default true */
    autoGrow?: boolean;
    /** Whether the input is disabled. @default false */
    disabled?: boolean;
    /** Error message shown below the textarea. When present, error border styling is applied. */
    errorMessage?: string;
    /** Label text rendered above the textarea. */
    label?: string;
    /** Helper text rendered below the textarea (hidden when errorMessage is present). */
    helperText?: string;
    /** Show character count next to the label. Requires `maxLength` to be set. @default false */
    showCount?: boolean;
    /** Show a required indicator next to the label. Pass `true` for default "*" or a custom ReactElement. @default false */
    requiredIndicator?: boolean | ReactElement;
    /** Custom renderer for the character counter. Overrides the default `{length}/{maxLength}` display. */
    renderCounter?: (info: {
        length: number;
        maxLength: number;
    }) => ReactNode;
}
//# sourceMappingURL=types.d.ts.map