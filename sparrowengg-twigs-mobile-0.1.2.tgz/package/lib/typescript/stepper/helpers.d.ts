import type { ViewStyle, TextStyle } from 'react-native';
import type { TwigsTheme } from '../theme';
export type StepState = 'active' | 'completed' | 'inactive' | 'disabled';
export declare function getStepState(stepIndex: number, activeStep: number, allowClick: boolean): StepState;
export declare function getCounterStyles(theme: TwigsTheme, state: StepState): ViewStyle;
export declare function getCounterTextStyles(theme: TwigsTheme, state: StepState): TextStyle;
export declare function getLabelTextStyles(theme: TwigsTheme, state: StepState): TextStyle;
export declare function getContainerStyles(theme: TwigsTheme): ViewStyle;
export declare function getUnderlineStyles(theme: TwigsTheme): ViewStyle;
//# sourceMappingURL=helpers.d.ts.map