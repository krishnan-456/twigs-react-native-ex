import React from 'react';
import type { View } from 'react-native';
import type { StepperItemProps } from './types';
/** StepperItem is a declarative child — it does not render itself directly. */
export declare const StepperItem: React.ForwardRefExoticComponent<StepperItemProps & React.RefAttributes<View>>;
//# sourceMappingURL=stepper-item.d.ts.map