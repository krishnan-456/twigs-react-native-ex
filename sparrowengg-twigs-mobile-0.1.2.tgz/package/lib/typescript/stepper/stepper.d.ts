import React from 'react';
import { View } from 'react-native';
import type { StepperProps } from './types';
/** Root Stepper component. Renders a trigger bar with step items and active content. */
export declare const Stepper: React.ForwardRefExoticComponent<StepperProps & React.RefAttributes<View>>;
//# sourceMappingURL=stepper.d.ts.map