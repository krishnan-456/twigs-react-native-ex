import React from 'react';
export declare const TickIcon: React.FC<{
    color: string;
}>;
export declare const ArrowConnectorIcon: React.FC<{
    color: string;
}>;
//# sourceMappingURL=icons.d.ts.map