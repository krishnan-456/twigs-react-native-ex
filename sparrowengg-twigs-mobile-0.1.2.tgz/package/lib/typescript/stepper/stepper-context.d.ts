export interface StepperContextValue {
    /** Index of the currently active step. */
    activeStep: number;
    /** Total number of steps. */
    totalSteps: number;
    /** Called when a step trigger is pressed. */
    onStepPress: (step: number) => void;
}
declare const StepperContext: import("react").Context<StepperContextValue | null>;
export declare function useStepperContext(): StepperContextValue;
export { StepperContext };
//# sourceMappingURL=stepper-context.d.ts.map