import React from 'react';
import { type StepState } from './helpers';
interface StepTriggerProps {
    index: number;
    label: string;
    state: StepState;
    isCompleted: boolean;
    allowClick: boolean;
    onPress: (step: number) => void;
    onTriggerLayout?: (index: number, x: number, width: number) => void;
}
export declare const StepTrigger: React.FC<StepTriggerProps>;
export {};
//# sourceMappingURL=stepper-trigger.d.ts.map