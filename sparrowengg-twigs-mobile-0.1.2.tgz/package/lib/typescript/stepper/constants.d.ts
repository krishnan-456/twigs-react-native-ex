/** Step counter circle dimensions. */
export declare const COUNTER_SIZE = 20;
export declare const COUNTER_BORDER_WIDTH = 1.5;
export declare const COUNTER_BORDER_RADIUS = 999;
/** Tick icon dimensions inside completed counter. */
export declare const TICK_ICON_SIZE = 11;
export declare const TICK_STROKE_WIDTH = 1.5;
/** Step item layout. */
export declare const ITEM_HEIGHT = 48;
export declare const ITEM_PADDING_HORIZONTAL = 8;
export declare const ITEM_GAP = 8;
/** Container layout. */
export declare const CONTAINER_PADDING_HORIZONTAL = 24;
export declare const CONTAINER_GAP = 16;
/** Connector dimensions. */
export declare const CONNECTOR_WIDTH = 24;
/** Active underline dimensions. */
export declare const UNDERLINE_HEIGHT = 1;
export declare const ACTIVE_UNDERLINE_HEIGHT = 2;
/** Typography. */
export declare const STEP_FONT_SIZE = 14;
export declare const STEP_LETTER_SPACING = 0.028;
//# sourceMappingURL=constants.d.ts.map