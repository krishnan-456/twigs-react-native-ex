export declare const styles: {
    root: {
        flexDirection: "column";
    };
    triggerContainer: {
        flexGrow: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        paddingHorizontal: number;
        gap: number;
    };
    triggerContainerFitted: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        paddingHorizontal: number;
        gap: number;
    };
    item: {
        flex: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        height: number;
        paddingHorizontal: number;
        gap: number;
    };
    staticBorder: {
        height: number;
    };
    activeUnderline: {
        position: "absolute";
        bottom: number;
        height: number;
    };
    triggerWrapper: {
        overflow: "hidden";
    };
    connector: {
        width: number;
        justifyContent: "center";
    };
    disabled: {
        opacity: number;
    };
    content: {
        flexGrow: number;
    };
};
//# sourceMappingURL=styles.d.ts.map