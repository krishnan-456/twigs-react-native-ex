import React from 'react';
export declare const StepperConnector: React.FC;
//# sourceMappingURL=stepper-connector.d.ts.map