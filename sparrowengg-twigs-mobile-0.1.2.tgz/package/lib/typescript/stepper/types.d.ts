import type { ViewProps, PressableProps } from 'react-native';
import type { CommonStyleProps, BaseAccessibilityProps } from '../utils';
/** Props for the root Stepper container. */
export interface StepperProps extends Omit<ViewProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Index of the currently active step (0-based). */
    activeStep: number;
    /** Called when a step trigger is pressed. */
    onStepChange?: (step: number) => void;
    /** Custom connector renderer between step triggers. */
    renderConnector?: () => React.ReactNode;
    /** Content to render — should be StepperItem elements. */
    children: React.ReactNode;
    /** Whether the step triggers can scroll horizontally (default: true). When false, steps share equal width and labels truncate. */
    scrollable?: boolean;
}
/** Props for an individual step trigger within the Stepper. */
export interface StepperItemProps extends Omit<PressableProps, 'style'>, CommonStyleProps, BaseAccessibilityProps {
    /** Text label displayed next to the step number. */
    label: string;
    /** Whether this step trigger is clickable. */
    allowClick?: boolean;
    /** Content rendered when this step is active. */
    children?: React.ReactNode;
}
//# sourceMappingURL=types.d.ts.map